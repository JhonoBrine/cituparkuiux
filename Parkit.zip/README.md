# This application is using ReactJS and HTML-CSS-JS

Halfway finished _(About 83%)_, only remaining is to add SekyuPage and try/catch statements - modals (that appears if you are sure if you want to delete, having an error and many more) 
Note: Might add the try/catch statements other error-handling statements after the API is integrated into the frontend-system.

Codes are a bit in a jumbled and need cleaning up to properly check. Each pages has its own **designated folder** so there is that.

Temporary Accounts 

Admin > Username: 11-1111-111 Password: admin
Sekyu > Username: 22-2222-222 Password: sekyu _not yet implemented in the meantime_

**The backend is not yet integrated into the code.**
