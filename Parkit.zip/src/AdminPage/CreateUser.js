import React, { useState } from 'react';
import { Grid, Box, TextField, Button, Popover, Typography, List, ListItem, ListItemText } from '@mui/material';
import axios from 'axios';
import './styleAdmMain/AdminStyle.css';

export default function CreateUser() {
  const [anchorEl, setAnchorEl] = useState(null);
  const [userType, setUserType] = useState('');
  const [stickerId, setStickerId] = useState('');
  const [popoverOpen, setPopoverOpen] = useState(false);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleUserTypeChange = (selectedUserType) => {
    setUserType(selectedUserType);
    handleClose();
  };

  const generateStickerId = () => {
    const newStickerId = Math.floor(100 + Math.random() * 900);
    setStickerId(newStickerId.toString());
  };

  const handleCreateUser = () => {
    const birthDate = document.getElementById('outlined-basic-bday').value;
    const firstName = document.getElementById('outlined-basic-fname').value;
    const lastName = document.getElementById('outlined-basic-lname').value;
    const middleName = document.getElementById('outlined-basic-mname').value;
    
    console.log('firstName:', firstName);
    console.log('middleName:', middleName);
    console.log('lastName:', lastName);
    console.log('birthDate:', birthDate);
    
  
    const hasMiddleName = middleName.trim() !== '';
  
    const userTypeId = 1; // Replace with the actual user type ID
  
    const userData = {
      has_middle_name: hasMiddleName,
      sticker_generatedid: stickerId,
      user_birth_date: birthDate,
      userfname: firstName,
      user_joined_date: new Date().toISOString(),
      userlname: lastName,
      usermname: middleName,
      user_typeid: userTypeId, // Uncomment this line if needed
      // Add other properties as needed
    };
    
  
    axios.post('http://localhost:8080/users', userData)
      .then(response => {
        console.log(response.data);
        setPopoverOpen(true);
      })
      .catch(error => {
        console.error('Error creating user:', error);
        console.log('Request payload:', userData);
        console.error('Server response:', error.response);
      });
  };
  
  
  

  const storeUserType = (selectedUserType) => {
    // Make an API call to store the user type in the backend
    axios.post('http://localhost:8080/user-types', { userType: selectedUserType })
      .then(response => {
        console.log(response.data);
      })
      .catch(error => {
        console.error('Error storing user type:', error);
        console.error('Server response:', error.response);
      });
  };

  const handlePopoverClose = () => {
    setPopoverOpen(false);
  };

  return (
    <>
      <div className="admin-createuserContainer">
        <div>
          <Grid container spacing={2} className="customGrid">
            <Grid item xs={12}>
              <Box className="customBox" style={{ marginLeft: '5%', marginTop: '50px', outline: '5px solid #f6c301' }}>
                <div className='TextField'>
                  <div className='test'>
                    <TextField
                      id="outlined-basic"
                      label="USER TYPE"
                      variant="outlined"
                      onClick={handleClick}
                      value={userType}
                    />
                    <Popover
                      open={Boolean(anchorEl)}
                      anchorEl={anchorEl}
                      onClose={handleClose}
                      anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'center',
                      }}
                      transformOrigin={{
                        vertical: 'top',
                        horizontal: 'center',
                      }}
                    >
                      <List className='Usertype-popup'>
                        {['STUDENT', 'EMPLOYEE', 'SECURITY GUARD', 'ADMIN'].map((type) => (
                          <ListItem button key={type} onClick={() => handleUserTypeChange(type) }>
                            <ListItemText primary={type} />
                          </ListItem>
                        ))}
                      </List>
                    </Popover>
                  </div>
                  <div className='test'>
                    <TextField id="outlined-basic-fname" label="FIRST NAME" variant="outlined" />
                  </div>
                  <div className='test'>
                    <TextField id="outlined-basic-mname" label="MIDDLE NAME" variant="outlined" />
                  </div>
                  <div className='test'>
                    <TextField id="outlined-basic-lname" label="LAST NAME" variant="outlined" />
                  </div>
                  <div className='test'>
                    <TextField id="outlined-basic-bday" label="BIRTH DATE" variant="outlined" />
                  </div>
                  <div className='test'>
                    <TextField
                      id="outlined-basic"
                      label="STICKER ID"
                      variant="outlined"
                      style={{ marginLeft: '130px' }}
                      value={stickerId}
                      readOnly
                    />
                    <Button
                      style={{ backgroundColor: 'gold', marginLeft: '20px' }}
                      variant="contained"
                      onClick={generateStickerId}
                    >
                      GENERATE
                    </Button>
                  </div>
                </div>

                <div className='buttons'>
                  <div className='test'>
                    <Button style={{ backgroundColor: 'gold', color: 'maroon', fontWeight: 'bolder' }} variant="contained">
                      CANCEL
                    </Button>
                  </div>

                  <div className='test'>
                    <Button style={{ backgroundColor: 'gold' }} variant="contained" onClick={handleCreateUser}>
                      CREATE USER
                    </Button>
                  </div>
                </div>
              </Box>
            </Grid>
          </Grid>
        </div>

        <Popover
          open={popoverOpen}
          anchorEl={anchorEl}
          onClose={handlePopoverClose}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'center',
          }}
          transformOrigin={{
            vertical: 'bottom',
            horizontal: 'center',
          }}
        >
          <Box p={2}>
            <Typography className='CreateUser-PopUp'>USER SUCCESSFULLY CREATED</Typography>
            <Button style={{ backgroundColor: 'gold', marginTop: '10px' }} onClick={handlePopoverClose}>
              CLOSE
            </Button>
          </Box>
        </Popover>
      </div>
    </>
  );
}
